# SAM.AI backend API contract (starter)

All endpoints should require authenticated sessions except the OAuth callback. Return JSON and meaningful HTTP status codes. Store all provider credentials server-side.

## Upload source video
`POST /v1/videos/upload` — multipart field `video`
Response: `{"video_id":"vid_123","status":"uploaded"}`

## Generate clips
`POST /v1/clips/generate`
```json
{"video_id":"vid_123","clip_count":5,"max_duration_seconds":60,"aspect_ratio":"9:16","language":"English","captions":true}
```
Response: `{"job_id":"job_123","status":"queued"}`

## Generate video from prompt
`POST /v1/videos/generate`
```json
{"prompt":"A cinematic city at sunset","style":"Cinematic","aspect_ratio":"9:16","duration_seconds":15}
```
Response: `{"job_id":"job_456","status":"queued"}`

## YouTube OAuth
`POST /v1/youtube/connect-url` → `{"authorization_url":"https://accounts.google.com/..."}`

## Publish
`POST /v1/youtube/upload`
```json
{"video_id":"render_123","title":"My video","description":"Description","made_for_kids":false}
```
Response: `{"job_id":"upload_123","status":"queued"}`

## Analytics
`GET /v1/analytics` → `{"views":0,"videos":0,"subscribers":0,"watch_time_minutes":0}`

## Recommended additional endpoints
- `GET /v1/jobs/{job_id}` for progress/status and errors
- `GET /v1/projects` and `GET /v1/projects/{project_id}`
- `GET /v1/videos/{video_id}/clips`
- `POST /v1/clips/{clip_id}/render`
- `POST /v1/auth/...` for secure sign-in/session lifecycle
