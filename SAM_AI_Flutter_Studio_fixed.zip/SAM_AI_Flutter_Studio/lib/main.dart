import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'api_service.dart';

const bg = Color(0xFF080A16);
const panel = Color(0xFF14182B);
const panel2 = Color(0xFF1C2140);
const purple = Color(0xFF8B45F7);
const pink = Color(0xFFEC35B8);
const cyan = Color(0xFF16D7F2);
const green = Color(0xFF22D68A);

void main() => runApp(const SamAiApp());

class SamAiApp extends StatelessWidget {
  const SamAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'SAM.AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: purple,
            brightness: Brightness.dark,
            surface: panel,
          ),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(
            backgroundColor: bg,
            surfaceTintColor: Colors.transparent,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: panel2,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const MainShell(),
      );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final titles = const ['Home', 'Projects', 'Create', 'Analytics', 'Profile'];
  final pages = const [
    HomePage(),
    ProjectsPage(),
    CreatePage(),
    AnalyticsPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          titleSpacing: 18,
          title: Row(children: [
            const Icon(Icons.play_circle_fill_rounded, color: cyan, size: 30),
            const SizedBox(width: 8),
            const Text('SAM', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 23)),
            const Text('.AI', style: TextStyle(color: pink, fontWeight: FontWeight.w900, fontSize: 23)),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: purple.withOpacity(.18), borderRadius: BorderRadius.circular(20)),
              child: const Text('STUDIO', style: TextStyle(fontSize: 9, letterSpacing: 1.2, color: Color(0xFFC8A8FF), fontWeight: FontWeight.bold)),
            ),
          ]),
          actions: [
            IconButton(
              tooltip: 'Notifications',
              onPressed: () => showMessage(context, 'You are all caught up.'),
              icon: const Icon(Icons.notifications_none_rounded),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: CircleAvatar(
                radius: 17,
                backgroundColor: purple.withOpacity(.25),
                child: const Icon(Icons.person_outline, color: Colors.white, size: 19),
              ),
            )
          ],
        ),
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          backgroundColor: const Color(0xFF101326),
          indicatorColor: purple.withOpacity(.25),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.video_library_outlined), selectedIcon: Icon(Icons.video_library), label: 'Projects'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Create'),
            NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Analytics'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: [
          const Text('Your AI video studio', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text('From long videos to viral clips — create, edit and publish.', style: TextStyle(color: Colors.white.withOpacity(.62))),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF442080), Color(0xFF192653), Color(0xFF28133E)]),
              border: Border.all(color: Colors.white.withOpacity(.12)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.auto_awesome, color: Color(0xFFFFD66B)),
                const SizedBox(width: 8),
                Text('SAM AI MAGIC', style: TextStyle(color: Colors.white.withOpacity(.8), fontWeight: FontWeight.bold, letterSpacing: 1.1, fontSize: 11)),
              ]),
              const SizedBox(height: 12),
              const Text('One video.\nMany possibilities.', style: TextStyle(fontSize: 27, height: 1.12, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('Repurpose long content, generate new videos and prepare content for every platform.', style: TextStyle(color: Colors.white.withOpacity(.78), height: 1.4)),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: FilledButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClipMakerPage())),
                  icon: const Icon(Icons.content_cut, size: 18),
                  label: const Text('Make clips'),
                  style: FilledButton.styleFrom(backgroundColor: purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
                )),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiVideoPage())),
                  icon: const Icon(Icons.movie_creation_outlined, size: 18),
                  label: const Text('AI video'),
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white38), padding: const EdgeInsets.symmetric(vertical: 14)),
                )),
              ])
            ]),
          ),
          const SizedBox(height: 24),
          const SectionHeading('Quick actions', trailing: 'CREATE FASTER'),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 11,
            crossAxisSpacing: 11,
            childAspectRatio: 1.45,
            children: [
              QuickCard(icon: Icons.video_call_outlined, title: 'Long video to clips', sub: 'Find highlights', color: pink, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClipMakerPage()))),
              QuickCard(icon: Icons.auto_awesome, title: 'AI video generator', sub: 'Text to video', color: purple, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiVideoPage()))),
              QuickCard(icon: Icons.subtitles_rounded, title: 'Auto captions', sub: 'Subtitles & styling', color: cyan, onTap: () => showMessage(context, 'Caption controls are available in the clip workflow.')),
              QuickCard(icon: Icons.record_voice_over, title: 'AI voice-over', sub: 'Narration workflow', color: green, onTap: () => showMessage(context, 'Voice generation requires a connected speech provider in your backend.')),
              QuickCard(icon: Icons.crop, title: 'Resize video', sub: '9:16 · 1:1 · 16:9', color: Colors.orange, onTap: () => showMessage(context, 'Choose an aspect ratio in the clip workflow.')),
              QuickCard(icon: Icons.cloud_upload_outlined, title: 'YouTube upload', sub: 'Publish your video', color: Colors.redAccent, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const YouTubePage()))),
            ],
          ),
          const SizedBox(height: 24),
          const SectionHeading('Your workflow'),
          const SizedBox(height: 12),
          const WorkflowRow(number: '01', title: 'Upload', detail: 'Import a long video from your device', color: cyan),
          const WorkflowRow(number: '02', title: 'Create', detail: 'Generate clips, captions and edits', color: purple),
          const WorkflowRow(number: '03', title: 'Publish', detail: 'Export or send to YouTube', color: pink),
          const SizedBox(height: 16),
          const InfoBanner(text: 'AI processing and YouTube publishing need your own backend API and OAuth credentials. This app is ready to connect to those services; it does not pretend to process videos offline.'),
        ],
      );
}

class ProjectsPage extends StatelessWidget {
  const ProjectsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('My projects', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    Text('Your uploaded videos and generated clips will appear here.', style: TextStyle(color: Colors.white.withOpacity(.6))),
    const SizedBox(height: 20),
    const EmptyState(icon: Icons.video_library_outlined, title: 'No projects yet', subtitle: 'Upload a video or create one with AI to start your workspace.'),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClipMakerPage())), icon: const Icon(Icons.upload_file), label: const Text('Upload a long video')),
  ]);
}

class CreatePage extends StatelessWidget {
  const CreatePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Create with AI', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    Text('Choose a creation workflow.', style: TextStyle(color: Colors.white.withOpacity(.6))),
    const SizedBox(height: 20),
    ActionTile(icon: Icons.content_cut, title: 'Long video → viral clips', subtitle: 'AI highlights, reframing and captions', color: pink, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClipMakerPage()))),
    ActionTile(icon: Icons.movie_filter_outlined, title: 'Text → AI video', subtitle: 'Generate a video from a prompt', color: purple, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiVideoPage()))),
    ActionTile(icon: Icons.closed_caption_outlined, title: 'Auto subtitles', subtitle: 'Transcribe speech and style captions', color: cyan, onTap: () => showMessage(context, 'Use the clip workflow with captions enabled.')),
    ActionTile(icon: Icons.graphic_eq, title: 'AI voice-over', subtitle: 'Narration and text-to-speech', color: green, onTap: () => showMessage(context, 'Connect a speech provider through your backend to enable voice generation.')),
    ActionTile(icon: Icons.aspect_ratio, title: 'Resize for social media', subtitle: 'Vertical, square and landscape exports', color: Colors.orange, onTap: () => showMessage(context, 'Aspect ratio options are available in the clip workflow.')),
    ActionTile(icon: Icons.cloud_upload_outlined, title: 'Publish to YouTube', subtitle: 'Connect channel and upload videos', color: Colors.redAccent, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const YouTubePage()))),
  ]);
}

class AnalyticsPage extends StatefulWidget {
  const AnalyticsPage({super.key});
  @override
  State<AnalyticsPage> createState() => _AnalyticsPageState();
}
class _AnalyticsPageState extends State<AnalyticsPage> {
  bool loading = false;
  String result = 'Connect your backend to load channel and video analytics.';
  Future<void> load() async {
    setState(() => loading = true);
    try {
      final data = await ApiService.instance.analytics();
      result = data.toString();
    } catch (e) { result = e.toString(); }
    if (mounted) setState(() => loading = false);
  }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Analytics', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    Text('Track your published content performance.', style: TextStyle(color: Colors.white.withOpacity(.6))),
    const SizedBox(height: 22),
    const Row(children: [
      Expanded(child: StatCard(label: 'Views', value: '—', icon: Icons.visibility_outlined)),
      SizedBox(width: 10),
      Expanded(child: StatCard(label: 'Videos', value: '—', icon: Icons.play_circle_outline)),
    ]),
    const SizedBox(height: 10),
    const Row(children: [
      Expanded(child: StatCard(label: 'Subscribers', value: '—', icon: Icons.people_outline)),
      SizedBox(width: 10),
      Expanded(child: StatCard(label: 'Watch time', value: '—', icon: Icons.schedule)),
    ]),
    const SizedBox(height: 18),
    FilledButton.icon(onPressed: loading ? null : load, icon: const Icon(Icons.refresh), label: Text(loading ? 'Loading…' : 'Refresh analytics')),
    const SizedBox(height: 14),
    InfoBanner(text: result),
  ]);
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Your account', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
    const SizedBox(height: 18),
    const Center(child: CircleAvatar(radius: 38, backgroundColor: panel2, child: Icon(Icons.person_outline, size: 38))),
    const SizedBox(height: 10),
    const Center(child: Text('SAM.AI Creator', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
    const Center(child: Text('Free workspace', style: TextStyle(color: Colors.white60))),
    const SizedBox(height: 24),
    ActionTile(icon: Icons.account_circle_outlined, title: 'Sign in / Create account', subtitle: 'Connect your authentication provider', color: purple, onTap: () => showMessage(context, 'Add Google, YouTube and email OAuth in your backend before enabling production sign-in.')),
    ActionTile(icon: Icons.play_circle_outline, title: 'Connect YouTube', subtitle: 'Authorize channel access securely', color: Colors.redAccent, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const YouTubePage()))),
    ActionTile(icon: Icons.settings_outlined, title: 'App settings', subtitle: 'API connection and preferences', color: cyan, onTap: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Backend connection'), content: Text(ApiService.instance.isConfigured ? 'API base URL is configured.' : 'Not configured. Build with --dart-define=SAM_API_BASE_URL=https://your-api.example.com'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))]))),
    const SizedBox(height: 16),
    const InfoBanner(text: 'Never put private API keys, OAuth client secrets or service-account credentials inside the mobile app. Keep secrets on your backend.'),
  ]);
}

class ClipMakerPage extends StatefulWidget {
  const ClipMakerPage({super.key});
  @override
  State<ClipMakerPage> createState() => _ClipMakerPageState();
}
class _ClipMakerPageState extends State<ClipMakerPage> {
  File? file;
  bool busy = false, captions = true;
  String ratio = '9:16', language = 'English';
  int count = 5, duration = 60;
  String status = 'Select a long video to begin.';
  Future<void> choose() async {
    final picked = await FilePicker.platform.pickFiles(type: FileType.video);
    if (picked?.files.single.path != null) {
      setState(() { file = File(picked!.files.single.path!); status = 'Video selected. Upload it to your SAM.AI backend.'; });
    }
  }
  Future<void> uploadAndCreate() async {
    if (file == null) { showMessage(context, 'Choose a video first.'); return; }
    setState(() { busy = true; status = 'Uploading video…'; });
    try {
      final uploaded = await ApiService.instance.uploadVideo(file!);
      final videoId = uploaded['video_id']?.toString() ?? uploaded['id']?.toString();
      if (videoId == null) throw const ApiException('Upload response must include video_id or id.');
      setState(() => status = 'Video uploaded. Generating clips…');
      final created = await ApiService.instance.createClips(
        videoId: videoId, clipCount: count, maxDuration: duration,
        aspectRatio: ratio, language: language, addCaptions: captions,
      );
      setState(() => status = 'Clip job created: ${created['job_id'] ?? created['id'] ?? created}');
    } catch (e) {
      setState(() => status = e.toString());
    } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Long video to clips')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Turn long videos into Shorts', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      Text('Upload a podcast, interview, tutorial or livestream. Your backend AI will find highlight moments and create short clips.', style: TextStyle(color: Colors.white.withOpacity(.65), height: 1.45)),
      const SizedBox(height: 20),
      PressCard(onTap: choose, child: Column(children: [
        const Icon(Icons.cloud_upload_outlined, size: 42, color: cyan),
        const SizedBox(height: 10),
        Text(file == null ? 'Choose video from device' : file!.path.split(Platform.pathSeparator).last, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        const Text('MP4, MOV and other video formats supported by your server', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
        const SizedBox(height: 10),
        const Text('BROWSE FILES', style: TextStyle(color: cyan, fontWeight: FontWeight.bold, letterSpacing: 1)),
      ])),
      const SizedBox(height: 18),
      const SectionHeading('Clip settings'),
      const SizedBox(height: 12),
      Text('Number of clips: $count'),
      Slider(value: count.toDouble(), min: 1, max: 15, divisions: 14, onChanged: (v) => setState(() => count = v.round())),
      Text('Maximum clip duration: $duration seconds'),
      Slider(value: duration.toDouble(), min: 15, max: 180, divisions: 11, onChanged: (v) => setState(() => duration = v.round())),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(value: ratio, decoration: const InputDecoration(labelText: 'Video format'), items: const [
        DropdownMenuItem(value: '9:16', child: Text('9:16 — Shorts / Reels / TikTok')),
        DropdownMenuItem(value: '1:1', child: Text('1:1 — Square')),
        DropdownMenuItem(value: '16:9', child: Text('16:9 — YouTube')),
      ], onChanged: (v) => setState(() => ratio = v ?? '9:16')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: language, decoration: const InputDecoration(labelText: 'Caption language'), items: const [
        DropdownMenuItem(value: 'English', child: Text('English')),
        DropdownMenuItem(value: 'Hindi', child: Text('Hindi')),
        DropdownMenuItem(value: 'Telugu', child: Text('Telugu')),
        DropdownMenuItem(value: 'Auto', child: Text('Auto detect')),
      ], onChanged: (v) => setState(() => language = v ?? 'English')),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: captions, activeColor: purple, onChanged: (v) => setState(() => captions = v), title: const Text('Generate animated captions'), subtitle: const Text('Speech-to-text subtitles on every clip')),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: busy ? null : uploadAndCreate, icon: const Icon(Icons.auto_awesome), label: Text(busy ? 'Please wait…' : 'Upload & generate clips'), style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.symmetric(vertical: 15))),
      const SizedBox(height: 12),
      InfoBanner(text: status),
    ]),
  );
}

class AiVideoPage extends StatefulWidget {
  const AiVideoPage({super.key});
  @override
  State<AiVideoPage> createState() => _AiVideoPageState();
}
class _AiVideoPageState extends State<AiVideoPage> {
  final prompt = TextEditingController();
  String style = 'Cinematic', ratio = '9:16';
  int duration = 15;
  bool busy = false;
  String status = 'Describe the video you want to create.';
  Future<void> generate() async {
    if (prompt.text.trim().isEmpty) { showMessage(context, 'Enter a video prompt first.'); return; }
    setState(() => busy = true);
    try {
      final r = await ApiService.instance.generateVideo(prompt: prompt.text.trim(), style: style, aspectRatio: ratio, duration: duration);
      setState(() => status = 'Generation job created: ${r['job_id'] ?? r['id'] ?? r}');
    } catch (e) { setState(() => status = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  void dispose() { prompt.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI video generator')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Imagine it. Generate it.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      Text('Write a prompt and send it to your connected video-generation provider.', style: TextStyle(color: Colors.white.withOpacity(.65))),
      const SizedBox(height: 20),
      TextField(controller: prompt, minLines: 5, maxLines: 8, decoration: const InputDecoration(hintText: 'Example: A cinematic aerial shot of a futuristic city at sunset, glowing neon lights, smooth camera movement…', labelText: 'Describe your video')),
      const SizedBox(height: 14),
      DropdownButtonFormField<String>(value: style, decoration: const InputDecoration(labelText: 'Visual style'), items: const [
        DropdownMenuItem(value: 'Cinematic', child: Text('Cinematic')),
        DropdownMenuItem(value: 'Realistic', child: Text('Realistic')),
        DropdownMenuItem(value: 'Animation', child: Text('Animation')),
        DropdownMenuItem(value: '3D', child: Text('3D')),
        DropdownMenuItem(value: 'Documentary', child: Text('Documentary')),
      ], onChanged: (v) => setState(() => style = v ?? 'Cinematic')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: ratio, decoration: const InputDecoration(labelText: 'Aspect ratio'), items: const [
        DropdownMenuItem(value: '9:16', child: Text('9:16 — Vertical')),
        DropdownMenuItem(value: '16:9', child: Text('16:9 — Landscape')),
        DropdownMenuItem(value: '1:1', child: Text('1:1 — Square')),
      ], onChanged: (v) => setState(() => ratio = v ?? '9:16')),
      const SizedBox(height: 12),
      Text('Duration: $duration seconds'),
      Slider(value: duration.toDouble(), min: 5, max: 60, divisions: 11, onChanged: (v) => setState(() => duration = v.round())),
      FilledButton.icon(onPressed: busy ? null : generate, icon: const Icon(Icons.auto_awesome), label: Text(busy ? 'Sending request…' : 'Generate video'), style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.symmetric(vertical: 15))),
      const SizedBox(height: 12),
      InfoBanner(text: status),
    ]),
  );
}

class YouTubePage extends StatefulWidget {
  const YouTubePage({super.key});
  @override
  State<YouTubePage> createState() => _YouTubePageState();
}
class _YouTubePageState extends State<YouTubePage> {
  bool busy = false;
  String status = 'Connect your YouTube channel to publish finished videos.';
  Future<void> connect() async {
    setState(() => busy = true);
    try {
      final r = await ApiService.instance.connectYouTube();
      setState(() => status = 'Authorization URL: ${r['authorization_url'] ?? r['url'] ?? r}');
    } catch (e) { setState(() => status = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('YouTube publishing')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)), child: const Column(children: [
        Icon(Icons.play_circle_fill, color: Colors.redAccent, size: 62),
        SizedBox(height: 12),
        Text('Publish directly to YouTube', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
        SizedBox(height: 8),
        Text('Authorize SAM.AI securely, choose a video and publish it to your channel.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, height: 1.4)),
      ])),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: busy ? null : connect, icon: const Icon(Icons.link), label: Text(busy ? 'Connecting…' : 'Connect YouTube'), style: FilledButton.styleFrom(backgroundColor: Colors.redAccent, padding: const EdgeInsets.symmetric(vertical: 15))),
      const SizedBox(height: 12),
      InfoBanner(text: status),
      const SizedBox(height: 10),
      const InfoBanner(text: 'Production upload needs Google OAuth consent, YouTube Data API enabled, user authorization and a backend endpoint. Never store OAuth client secrets in this app.'),
    ]),
  );
}

class SectionHeading extends StatelessWidget {
  const SectionHeading(this.title, {super.key, this.trailing});
  final String title;
  final String? trailing;
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
    if (trailing != null) Text(trailing!, style: const TextStyle(color: cyan, fontSize: 9, letterSpacing: 1.1, fontWeight: FontWeight.bold)),
  ]);
}

class QuickCard extends StatelessWidget {
  const QuickCard({super.key, required this.icon, required this.title, required this.sub, required this.color, required this.onTap});
  final IconData icon; final String title, sub; final Color color; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => PressCard(onTap: onTap, child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
    Icon(icon, color: color, size: 27), const SizedBox(height: 10),
    Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
    const SizedBox(height: 3), Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 11)),
  ]));
}

class ActionTile extends StatelessWidget {
  const ActionTile({super.key, required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  final IconData icon; final String title, subtitle; final Color color; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)),
    child: ListTile(onTap: onTap, contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      leading: CircleAvatar(backgroundColor: color.withOpacity(.15), child: Icon(icon, color: color)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 11)),
      trailing: const Icon(Icons.chevron_right, color: Colors.white54),
    ),
  );
}

class PressCard extends StatelessWidget {
  const PressCard({super.key, required this.child, required this.onTap});
  final Widget child; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
    color: panel, borderRadius: BorderRadius.circular(18),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18),
      child: Container(width: double.infinity, padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: cyan.withOpacity(.25))),
        child: child,
      ),
    ),
  );
}

class WorkflowRow extends StatelessWidget {
  const WorkflowRow({super.key, required this.number, required this.title, required this.detail, required this.color});
  final String number, title, detail; final Color color;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Row(children: [
    Container(width: 42, height: 42, alignment: Alignment.center, decoration: BoxDecoration(color: color.withOpacity(.15), borderRadius: BorderRadius.circular(13)), child: Text(number, style: TextStyle(color: color, fontWeight: FontWeight.w900))),
    const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(detail, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    ])),
  ]));
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  final String label, value; final IconData icon;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, color: cyan), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
  ]));
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon; final String title, subtitle;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white10)), child: Column(children: [
    Icon(icon, size: 44, color: purple), const SizedBox(height: 12), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), const SizedBox(height: 6), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, height: 1.4)),
  ]));
}

class InfoBanner extends StatelessWidget {
  const InfoBanner({super.key, required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel2.withOpacity(.7), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Icon(Icons.info_outline, size: 18, color: cyan), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.45))),
  ]));
}

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
}
