import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// Configure with:
/// flutter run --dart-define=SAM_API_BASE_URL=https://your-api.example.com
class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  static const String baseUrl = String.fromEnvironment(
    'SAM_API_BASE_URL',
    defaultValue: '',
  );

  bool get isConfigured => baseUrl.trim().isNotEmpty;

  Uri _uri(String path) {
    if (!isConfigured) {
      throw const ApiException(
        'Backend is not configured. Set SAM_API_BASE_URL to your API server.',
      );
    }
    return Uri.parse('${baseUrl.replaceFirst(RegExp(r'/+$'), '')}$path');
  }

  Future<Map<String, dynamic>> _postJson(
    String path,
    Map<String, dynamic> body,
  ) async {
    final response = await http.post(
      _uri(path),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> _decode(http.Response response) async {
    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      decoded = {'message': response.body};
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException(
        (decoded is Map ? decoded['message'] : null)?.toString() ??
            'Request failed (${response.statusCode})',
      );
    }
    return decoded is Map<String, dynamic> ? decoded : {'data': decoded};
  }

  Future<Map<String, dynamic>> uploadVideo(File file) async {
    final request = http.MultipartRequest('POST', _uri('/v1/videos/upload'))
      ..files.add(await http.MultipartFile.fromPath('video', file.path));
    final streamed = await request.send();
    final response = await http.Response.fromStream(streamed);
    return _decode(response);
  }

  Future<Map<String, dynamic>> createClips({
    required String videoId,
    required int clipCount,
    required int maxDuration,
    required String aspectRatio,
    required String language,
    required bool addCaptions,
  }) =>
      _postJson('/v1/clips/generate', {
        'video_id': videoId,
        'clip_count': clipCount,
        'max_duration_seconds': maxDuration,
        'aspect_ratio': aspectRatio,
        'language': language,
        'captions': addCaptions,
      });

  Future<Map<String, dynamic>> generateVideo({
    required String prompt,
    required String style,
    required String aspectRatio,
    required int duration,
  }) =>
      _postJson('/v1/videos/generate', {
        'prompt': prompt,
        'style': style,
        'aspect_ratio': aspectRatio,
        'duration_seconds': duration,
      });

  Future<Map<String, dynamic>> connectYouTube() =>
      _postJson('/v1/youtube/connect-url', {});

  Future<Map<String, dynamic>> publishToYouTube({
    required String videoId,
    required String title,
    required String description,
    required bool madeForKids,
  }) =>
      _postJson('/v1/youtube/upload', {
        'video_id': videoId,
        'title': title,
        'description': description,
        'made_for_kids': madeForKids,
      });

  Future<Map<String, dynamic>> analytics() async {
    final response = await http.get(_uri('/v1/analytics'));
    return _decode(response);
  }
}

class ApiException implements Exception {
  const ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}
