import 'package:flutter_test/flutter_test.dart';
import 'package:sam_ai/main.dart';

void main() {
  testWidgets('SAM.AI dashboard renders', (tester) async {
    await tester.pumpWidget(const SamAiApp());
    expect(find.text('SAM'), findsOneWidget);
    expect(find.text('Your AI video studio'), findsOneWidget);
    expect(find.text('Long video to clips'), findsOneWidget);
  });
}
