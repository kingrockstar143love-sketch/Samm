# SAM.AI Studio — Flutter Android app

This project upgrades the original SAM_AI Flutter starter dashboard into a multi-screen video-creator app following the supplied SAM.AI reference.

## Included in this app

- Home dashboard and quick actions
- Projects workspace and analytics screen
- Video file picker for long-form uploads
- Clip-generation settings: clip count, duration, aspect ratio and caption language
- Text-to-video prompt screen with style, aspect ratio and duration
- YouTube connect flow screen
- Profile and backend configuration information
- Dark navy / purple / pink SAM.AI design
- GitHub Actions workflow to build a release APK

## Important: AI services need a backend

This is a Flutter mobile client. Real AI video generation, automatic highlight detection, transcription, animated captions, voice generation, rendering, cloud storage, YouTube OAuth/upload and analytics cannot be implemented securely by a mobile UI alone. Connect a backend and AI/video providers to activate those workflows.

The app calls these backend endpoints:

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/v1/videos/upload` | Multipart upload; expects `video_id` or `id` |
| POST | `/v1/clips/generate` | Create clips from uploaded video |
| POST | `/v1/videos/generate` | Generate a video from text prompt |
| POST | `/v1/youtube/connect-url` | Return OAuth authorization URL |
| POST | `/v1/youtube/upload` | Publish a processed video |
| GET | `/v1/analytics` | Return channel/project analytics |

### Configure API base URL

For local testing:

```bash
flutter run --dart-define=SAM_API_BASE_URL=http://10.0.2.2:8000
```

For a deployed server:

```bash
flutter build apk --release --dart-define=SAM_API_BASE_URL=https://YOUR_BACKEND_DOMAIN
```

Replace the example with your HTTPS backend URL. Do not place private provider keys, Google OAuth client secrets, or service-account credentials in Flutter source code. Keep them on the backend.

### Suggested backend capabilities

Use a secure API server with:
- Authentication (Google/email OAuth and session management)
- Object storage for uploaded source videos and rendered clips
- FFmpeg for trimming, resizing, encoding and export
- Speech-to-text for transcription and subtitles
- An AI highlight/ranking service for finding clip-worthy moments
- A video-generation provider for prompt-to-video
- Text-to-speech provider for voice-over
- Google OAuth + YouTube Data API for publishing
- Job queue and status polling/webhooks for long-running renders
- Database for projects, users, jobs and analytics

The mobile app currently submits jobs and displays the API response. A production backend should return job IDs and provide job-status endpoints; add polling/websocket updates and a clip review/editor screen as the backend contract is finalized.

## Build APK using GitHub

1. Create a GitHub repository named `SAM-AI`.
2. Extract this ZIP.
3. Upload the **contents of `SAM_AI_Flutter_Studio`** into the repository root. `pubspec.yaml`, `lib/`, `test/` and `.github/` must be directly at the root.
4. Open **Actions** and select **SAM.AI Android APK Build**.
5. Run the workflow or push a commit to `main`.
6. After a successful green run, open the workflow run and download artifact **SAM-AI-APK**.
7. Extract the artifact ZIP; it contains `app-release.apk`.

## Build locally

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

APK output:

`build/app/outputs/flutter-apk/app-release.apk`

## Verification

This source package was generated here, but Flutter/Dart SDK execution is not available in this environment. Run the GitHub Actions workflow to compile, analyze and test it. The build may require dependency/API adjustments if a newer Flutter SDK changes package compatibility.
